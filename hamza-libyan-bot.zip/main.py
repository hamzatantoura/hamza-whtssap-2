from flask import Flask, request
import os
from twilio.twiml.messaging_response import MessagingResponse
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# OpenAI API Key
openai.api_key = os.getenv("OPENAI_API_KEY")

# Route for Twilio Webhook
@app.route("/webhook", methods=["POST"])
def whatsapp_webhook():
    # Parse incoming message
    incoming_msg = request.form.get("Body")
    response = MessagingResponse()
    msg = response.message()

    # Classify the message using GPT-4
    classification = classify_message(incoming_msg)

    # Generate response in Libyan dialect
    reply = generate_reply(classification, incoming_msg)
    msg.body(reply)

    return str(response)

# Function to classify message
def classify_message(message):
    prompt = f"""صنف النص التالي بناءً على حالته (طلب جديد، استفسار عام، دعم فني، غير مصنف):\nالنص: {message}\nالتصنيف:""" 
    try:
        completion = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=50
        )
        return completion.choices[0].text.strip()
    except Exception as e:
        return "غير مصنف"

# Function to generate reply in Libyan dialect
def generate_reply(classification, message):
    if "طلب جديد" in classification:
        return "تمام 🌟، توا هنكمل معاك طلبك. ممكن تبعتلنا اسمك، رقمك، والعنوان؟"
    elif "استفسار عام" in classification:
        return "أكيد! شن استفسارك؟ 🌿"
    elif "دعم فني" in classification:
        return "ما تقلقش ✨، بلغنا المشكلة اللي تواجهك وإن شاء الله نلقوا حل."
    else:
        return "معليش، مش فاهمينك كويس. ممكن توضح شني اللي تبيه؟"

if __name__ == "__main__":
    app.run(debug=True)
